-- phpMyAdmin SQL Dump
-- version 4.0.1
-- http://www.phpmyadmin.net
--
-- ホスト: localhost
-- 生成日時: 2013 年 9 月 14 日 14:24
-- サーバのバージョン: 5.6.11
-- PHP のバージョン: 5.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- データベース: `casemondai`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `answers`
--

DROP TABLE IF EXISTS `answers`;
CREATE TABLE IF NOT EXISTS `answers` (
  `answerId` int(11) NOT NULL AUTO_INCREMENT COMMENT '解答ID',
  `questionId` int(11) NOT NULL COMMENT '問題ID',
  `userId` int(11) NOT NULL COMMENT '解答を投稿したユーザーID',
  `answer` varchar(2000) NOT NULL COMMENT '解答',
  `created` datetime NOT NULL COMMENT '解答を投稿した日時',
  PRIMARY KEY (`answerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- テーブルの構造 `cake_sessions`
--

DROP TABLE IF EXISTS `cake_sessions`;
CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES
('gqtpbheheh5o7pqmov8eqf6770', 'Config|a:3:{s:9:"userAgent";s:32:"b940c113fa30df84ac1b33c2e3c828f1";s:4:"time";i:1391146344;s:9:"countdown";i:10;}Message|a:0:{}Auth|a:1:{s:8:"redirect";s:13:"/users/logout";}', 1391146344),
('61md73mucl9htfdjkh5l1f1ln1', 'Config|a:3:{s:9:"userAgent";s:32:"b940c113fa30df84ac1b33c2e3c828f1";s:4:"time";i:1391156276;s:9:"countdown";i:10;}Auth|a:1:{s:4:"User";a:6:{s:2:"id";s:1:"8";s:5:"email";N;s:8:"password";s:40:"2f314434c72fef50e2c3117b61860a0351aaae1d";s:4:"role";N;s:7:"created";s:19:"2013-08-04 14:44:07";s:11:"facebook_id";s:10:"1308820639";}}FB|a:1:{s:2:"Me";N;}', 1391156276),
('5vgmatdqghlggo7q22duapda02', 'Config|a:3:{s:9:"userAgent";s:32:"9230c21770c39781bbfcc2efcb65b929";s:4:"time";i:1394688014;s:9:"countdown";i:10;}fb_174830916022330_user_id|s:15:"100000546134163";', 1394688015),
('hvgdct56u7pd77jeemutm2r783', 'Config|a:3:{s:9:"userAgent";s:32:"bfb52b9fe24c2f5826479ec0cfb131b9";s:4:"time";i:1393977064;s:9:"countdown";i:10;}', 1393977064);

-- --------------------------------------------------------

--
-- テーブルの構造 `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `questionId` int(11) NOT NULL AUTO_INCREMENT COMMENT '問題ID',
  `questionTitle` varchar(30) NOT NULL COMMENT '問題のタイトル',
  `questionContent` varchar(300) NOT NULL COMMENT '問題文',
  `userId` int(11) NOT NULL COMMENT '投稿したユーザーのID',
  `created` datetime NOT NULL COMMENT '投稿日時',
  `updated` datetime NOT NULL COMMENT '最終更新日時（解答があれば最終解答日時、解答がなければ問題の投稿日時）',
  PRIMARY KEY (`questionId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='問題' AUTO_INCREMENT=3 ;

--
-- テーブルのデータのダンプ `questions`
--

INSERT INTO `questions` (`questionId`, `questionTitle`, `questionContent`, `userId`, `created`, `updated`) VALUES
(1, '日本で1日に使われるトイレットペーパーの消費量は？', '日本全国で１日に使用されるトイレットペーパーの消費量が知りたい。どんな方法で推測したら良いだろうか？', 1, '2013-09-08 00:00:00', '0000-00-00 00:00:00'),
(2, 'シカゴにピアノ調律師は何人いるか？', 'アメリカのシカゴ州に存在するピアノ調律師の人数を求めよ。', 2, '2013-09-08 20:18:00', '2013-09-10 20:20:00');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(120) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `facebook_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
