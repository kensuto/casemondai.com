-- phpMyAdmin SQL Dump
-- version 4.0.1
-- http://www.phpmyadmin.net
--
-- ホスト: localhost
-- 生成日時: 2013 年 8 月 04 日 17:33
-- サーバのバージョン: 5.6.11
-- PHP のバージョン: 5.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- データベース: `casemondai`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `cake_sessions`
--

DROP TABLE IF EXISTS `cake_sessions`;
CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES
('gqtpbheheh5o7pqmov8eqf6770', 'Config|a:3:{s:9:"userAgent";s:32:"b940c113fa30df84ac1b33c2e3c828f1";s:4:"time";i:1391146344;s:9:"countdown";i:10;}Message|a:0:{}Auth|a:1:{s:8:"redirect";s:13:"/users/logout";}', 1391146344),
('61md73mucl9htfdjkh5l1f1ln1', 'Config|a:3:{s:9:"userAgent";s:32:"b940c113fa30df84ac1b33c2e3c828f1";s:4:"time";i:1391156276;s:9:"countdown";i:10;}Auth|a:1:{s:4:"User";a:6:{s:2:"id";s:1:"8";s:5:"email";N;s:8:"password";s:40:"2f314434c72fef50e2c3117b61860a0351aaae1d";s:4:"role";N;s:7:"created";s:19:"2013-08-04 14:44:07";s:11:"facebook_id";s:10:"1308820639";}}FB|a:1:{s:2:"Me";N;}', 1391156276);

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(120) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `facebook_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
