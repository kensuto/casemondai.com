-- phpMyAdmin SQL Dump
-- version 4.0.1
-- http://www.phpmyadmin.net
--
-- ホスト: localhost
-- 生成日時: 2013 年 9 月 17 日 01:39
-- サーバのバージョン: 5.6.11
-- PHP のバージョン: 5.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- データベース: `casemondai`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `answers`
--

DROP TABLE IF EXISTS `answers`;
CREATE TABLE IF NOT EXISTS `answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '解答ID',
  `question_id` int(11) DEFAULT NULL COMMENT '問題ID',
  `user_id` varchar(11) DEFAULT NULL COMMENT '解答を投稿したユーザーID',
  `answer` varchar(2000) NOT NULL COMMENT '解答',
  `created` datetime NOT NULL COMMENT '解答を投稿した日時',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- テーブルのデータのダンプ `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `user_id`, `answer`, `created`) VALUES
(1, NULL, NULL, 'Joe', '2013-09-15 00:09:36'),
(2, NULL, NULL, 'Joe', '2013-09-15 00:09:40'),
(3, NULL, NULL, 'Joe', '2013-09-15 00:12:45'),
(4, NULL, NULL, 'dddddddddd', '2013-09-15 01:12:03'),
(5, NULL, NULL, 'dddddddddd', '2013-09-15 01:12:31'),
(6, NULL, NULL, '', '2013-09-15 01:38:48'),
(7, NULL, NULL, '改行', '2013-09-15 01:50:51'),
(8, NULL, NULL, '改行', '2013-09-15 01:50:56'),
(9, NULL, NULL, '改行', '2013-09-15 01:51:14'),
(10, NULL, NULL, '', '2013-09-15 02:04:32'),
(11, NULL, NULL, '', '2013-09-15 02:11:05'),
(12, NULL, NULL, 'fdsa', '2013-09-15 02:11:45'),
(13, NULL, NULL, 'テストテスト', '2013-09-15 17:13:17'),
(14, NULL, NULL, 'ddd', '2013-09-16 15:32:24');

-- --------------------------------------------------------

--
-- テーブルの構造 `cake_sessions`
--

DROP TABLE IF EXISTS `cake_sessions`;
CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES
('gqtpbheheh5o7pqmov8eqf6770', 'Config|a:3:{s:9:"userAgent";s:32:"b940c113fa30df84ac1b33c2e3c828f1";s:4:"time";i:1391146344;s:9:"countdown";i:10;}Message|a:0:{}Auth|a:1:{s:8:"redirect";s:13:"/users/logout";}', 1391146344),
('61md73mucl9htfdjkh5l1f1ln1', 'Config|a:3:{s:9:"userAgent";s:32:"b940c113fa30df84ac1b33c2e3c828f1";s:4:"time";i:1391156276;s:9:"countdown";i:10;}Auth|a:1:{s:4:"User";a:6:{s:2:"id";s:1:"8";s:5:"email";N;s:8:"password";s:40:"2f314434c72fef50e2c3117b61860a0351aaae1d";s:4:"role";N;s:7:"created";s:19:"2013-08-04 14:44:07";s:11:"facebook_id";s:10:"1308820639";}}FB|a:1:{s:2:"Me";N;}', 1391156276),
('5vgmatdqghlggo7q22duapda02', 'Config|a:3:{s:9:"userAgent";s:32:"9230c21770c39781bbfcc2efcb65b929";s:4:"time";i:1394878067;s:9:"countdown";i:10;}Auth|a:1:{s:8:"redirect";s:15:"/users/register";}fb_174830916022330_user_id|s:15:"100000546134163";', 1394878067),
('hvgdct56u7pd77jeemutm2r783', 'Config|a:3:{s:9:"userAgent";s:32:"bfb52b9fe24c2f5826479ec0cfb131b9";s:4:"time";i:1393977064;s:9:"countdown";i:10;}', 1393977064);

-- --------------------------------------------------------

--
-- テーブルの構造 `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '問題ID',
  `title` varchar(30) NOT NULL COMMENT '問題のタイトル',
  `content` varchar(300) NOT NULL COMMENT '問題文',
  `user_id` int(11) DEFAULT NULL COMMENT '投稿したユーザーのID',
  `created` datetime NOT NULL COMMENT '投稿日時',
  `updated` datetime NOT NULL COMMENT '最終更新日時（解答があれば最終解答日時、解答がなければ問題の投稿日時）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='問題' AUTO_INCREMENT=20 ;

--
-- テーブルのデータのダンプ `questions`
--

INSERT INTO `questions` (`id`, `title`, `content`, `user_id`, `created`, `updated`) VALUES
(1, '日本で1日に使われるトイレットペーパーの消費量は？', '日本全国で１日に使用されるトイレットペーパーの消費量が知りたい。どんな方法で推測したら良いだろうか？', 1, '2013-09-08 00:00:00', '0000-00-00 00:00:00'),
(2, 'シカゴにピアノ調律師は何人いるか？', 'アメリカのシカゴ州に存在するピアノ調律師の人数を求めよ。', 2, '2013-09-08 20:18:00', '2013-09-10 20:20:00'),
(3, 'test', 'test', NULL, '2013-09-14 21:35:49', '2013-09-14 21:35:49'),
(4, 'test', 'test', NULL, '2013-09-14 21:35:50', '2013-09-14 21:35:50'),
(5, 'test', 'test', NULL, '2013-09-14 21:47:04', '2013-09-14 21:47:04'),
(6, 'test', 'test', NULL, '2013-09-14 21:49:06', '2013-09-14 21:49:06'),
(7, 'test', 'test', NULL, '2013-09-14 21:50:28', '2013-09-14 21:50:28'),
(8, 'test', 'test', NULL, '2013-09-14 21:50:54', '2013-09-14 21:50:54'),
(9, 'test', 'test', NULL, '2013-09-14 22:03:41', '2013-09-14 22:03:41'),
(10, 'test', 'test', NULL, '2013-09-14 22:10:12', '2013-09-14 22:10:12'),
(11, 'test', 'test', NULL, '2013-09-14 22:10:12', '2013-09-14 22:10:12'),
(12, 'test', 'test', NULL, '2013-09-14 22:11:45', '2013-09-14 22:11:45'),
(13, 'test', 'test', NULL, '2013-09-14 22:14:37', '2013-09-14 22:14:37'),
(14, 'umizaru', 'umizaru', NULL, '2013-09-14 22:57:35', '2013-09-14 22:57:35'),
(15, 'umizaru', 'umizaru', NULL, '2013-09-14 23:16:01', '2013-09-14 23:16:01'),
(16, 'umizaru', 'umizaru', NULL, '2013-09-14 23:18:42', '2013-09-14 23:18:42'),
(17, '星組', 'ちえねね', NULL, '2013-09-14 23:28:14', '2013-09-14 23:28:14'),
(18, 'タイトル', '本文', NULL, '2013-09-16 14:52:56', '2013-09-16 14:52:56'),
(19, 'CSSができました', 'トイレットペーパーの長さを求めます。', NULL, '2013-09-16 15:24:18', '2013-09-16 15:24:18');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ユーザーID',
  `facebook_id` bigint(20) unsigned DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL COMMENT 'メールアドレス',
  `name` varchar(256) DEFAULT NULL COMMENT 'ユーザーネーム',
  `password` varchar(50) DEFAULT NULL COMMENT 'パスワード',
  `birthday` date NOT NULL COMMENT '生年月日',
  `sex` tinyint(4) NOT NULL COMMENT '性別',
  `grd_year` year(4) NOT NULL COMMENT '卒業年',
  `grd_status` tinyint(4) NOT NULL COMMENT '卒業ステータス',
  `school` varchar(50) NOT NULL COMMENT '学校名',
  `school_type` tinyint(4) NOT NULL COMMENT '学校種別',
  `major` varchar(50) NOT NULL COMMENT '専攻',
  `optin` int(11) NOT NULL COMMENT 'お知らせメール受信',
  `role` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL COMMENT '登録日',
  `updated` datetime DEFAULT NULL COMMENT '更新日',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
