<?php
App::uses('FacebookInfo', 'Facebook.Lib');
class FacebookAppModel extends AppModel {

}

?>